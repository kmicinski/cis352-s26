#lang racket

(require "../../interp-ce.rkt")

(define prog
  '(car (cdr (cons 1 (cons 2 (cons 3 '()))))))

(with-output-to-file "output"
                     (lambda ()
                       (print (interp-ce prog)))
                     #:exists 'replace)
