#lang racket

(require "../../interp-ce.rkt")

(define prog
  '(let ([f (lambda (x) (* x x))])
     (f 6)))

(with-output-to-file "output"
                     (lambda ()
                       (print (interp-ce prog)))
                     #:exists 'replace)
