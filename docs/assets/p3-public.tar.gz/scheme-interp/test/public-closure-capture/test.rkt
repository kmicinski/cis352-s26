#lang racket

(require "../../interp-ce.rkt")

(define prog
  '(let ([x 10])
     ((lambda (y) (+ x y)) 5)))

(with-output-to-file "output"
                     (lambda ()
                       (print (interp-ce prog)))
                     #:exists 'replace)
