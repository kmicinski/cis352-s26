#lang racket

(require "../../interp-ce.rkt")

(define prog
  '(or #f #f 42))

(with-output-to-file "output"
                     (lambda ()
                       (print (interp-ce prog)))
                     #:exists 'replace)
