#lang racket

(require "../../interp-ce.rkt")

(with-output-to-file "output"
                     (lambda ()
                       (print (interp-ce '#t)))
                     #:exists 'replace)
