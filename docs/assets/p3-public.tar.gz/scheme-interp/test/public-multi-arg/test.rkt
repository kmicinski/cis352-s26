#lang racket

(require "../../interp-ce.rkt")

(define prog
  '((lambda (x y z) (+ x (+ y z))) 1 2 3))

(with-output-to-file "output"
                     (lambda ()
                       (print (interp-ce prog)))
                     #:exists 'replace)
