#lang racket

(require "../../interp-ce.rkt")

(define prog
  '(((lambda (x) (lambda (y) (+ x y))) 3) 4))

(with-output-to-file "output"
                     (lambda ()
                       (print (interp-ce prog)))
                     #:exists 'replace)
