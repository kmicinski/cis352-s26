#lang racket

(require "../../interp-ce.rkt")

(define prog
  '(if (= 1 2) 10
       (if (= 2 3) 20
           (if (= 3 3) 30 40))))

(with-output-to-file "output"
                     (lambda ()
                       (print (interp-ce prog)))
                     #:exists 'replace)
